// const String apiBaseUrl = "http://localhost:3089/api/v1";
const String apiBaseUrl =
    "https://0ccb-2400-1a00-bd11-80f1-9caa-d6dc-4778-52c1.ngrok-free.app/api/v1";
const String appTitle = "MeroBus";
// const String imageUrl = "http://localhost:3089";
const String imageUrl =
    "https://0ccb-2400-1a00-bd11-80f1-9caa-d6dc-4778-52c1.ngrok-free.app";
