// const String apiBaseUrl = "http://localhost:3089/api/v1";
const String apiBaseUrl =
    "https://90db-2001-df7-be80-2362-b43e-c500-6584-10c7.ngrok-free.app/api/v1";
const String appTitle = "MeroBus";
// const String imageUrl = "http://localhost:3089";
const String imageUrl =
    "https://90db-2001-df7-be80-2362-b43e-c500-6584-10c7.ngrok-free.app";
// const socketBaseUrl = "http://localhost:3089";
const socketBaseUrl =
    "https://90db-2001-df7-be80-2362-b43e-c500-6584-10c7.ngrok-free.app";
