const String apiBaseUrl = "http://localhost:3089/api/v1";
// const String apiBaseUrl =
//     "https://a2e2-2001-df7-be80-369c-24ab-7e89-72ae-5ba9.ngrok-free.app/api/v1";
const String appTitle = "MeroBus";
const String imageUrl = "http://localhost:3089";
// const String imageUrl =
//     "https://a2e2-2001-df7-be80-369c-24ab-7e89-72ae-5ba9.ngrok-free.app";
