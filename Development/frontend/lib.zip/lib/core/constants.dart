const String apiBaseUrl = "http://localhost:3089/api/v1";
const String appTitle = "MeroBus";
const String imageUrl = "http://localhost:3089";
