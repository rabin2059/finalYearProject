enum UserRole { USER, DRIVER, ADMIN }
