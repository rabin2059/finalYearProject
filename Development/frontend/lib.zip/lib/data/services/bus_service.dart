import 'dart:convert';
import 'package:frontend/data/models/bus_model.dart';
import 'package:http/http.dart' as http;

class BusService {
  final String baseUrl;

  BusService({required this.baseUrl});

  /// Fetch Buses from API
  Future<List<Bus>> getBuses() async {
    try {
      final uri = Uri.parse('$baseUrl/getVehicles');

      final response = await http.get(
        uri,
        headers: {'Content-Type': 'application/json'},
      );

      // Check HTTP status code
      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        print(jsonResponse);

        // Validate the response before parsing
        if (jsonResponse.isEmpty) {
          throw Exception('No buses available at the moment.');
        }

        return jsonResponse.map((busJson) => Bus.fromJson(busJson)).toList();
      } else if (response.statusCode == 404) {
        throw Exception('Bus data not found (404).');
      } else if (response.statusCode == 500) {
        throw Exception('Server error. Please try again later.');
      } else {
        throw Exception('Unexpected error: ${response.statusCode}');
      }
    } catch (e) {
      // Log the error for debugging
      print('Error fetching buses: $e');
      throw Exception('Failed to fetch buses. Please check your connection.');
    }
  }
}