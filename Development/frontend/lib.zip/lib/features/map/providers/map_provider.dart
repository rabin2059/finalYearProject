import 'package:flutter_riverpod/flutter_riverpod.dart';

class MapNotifier extends StateNotifier<MapState> {
  
}