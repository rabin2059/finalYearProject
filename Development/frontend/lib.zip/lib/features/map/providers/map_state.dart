import 'package:flutter/foundation.dart';

/// Represents a marker on the map
class MapMarker {
  final double latitude;
  final double longitude;
  final String title;

  MapMarker({
    required this.latitude,
    required this.longitude,
    required this.title,
  });
}

/// **State for Managing Map Data**
@immutable
class MapState {
  final bool isLoading; // Whether map is loading
  final bool isAllowed; // Whether user has granted location permission
  final List<MapMarker> markers; // List of markers
  final double centerLat; // Map center latitude
  final double centerLng; // Map center longitude
  final double zoom; // Map zoom level

  const MapState({
    this.isLoading = false,
    this.isAllowed = false,
    this.markers = const [],
    this.centerLat = 0.0,
    this.centerLng = 0.0,
    this.zoom = 10.0,
  });

  /// **Creates a new copy of the state with updated values**
  MapState copyWith({
    bool? isLoading,
    bool? isAllowed,
    List<MapMarker>? markers,
    double? centerLat,
    double? centerLng,
    double? zoom,
  }) {
    return MapState(
      isLoading: isLoading ?? this.isLoading,
      isAllowed: isAllowed ?? this.isAllowed,
      markers: markers ?? this.markers,
      centerLat: centerLat ?? this.centerLat,
      centerLng: centerLng ?? this.centerLng,
      zoom: zoom ?? this.zoom,
    );
  }
}
