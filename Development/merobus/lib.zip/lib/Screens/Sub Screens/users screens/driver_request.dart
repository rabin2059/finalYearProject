import 'package:flutter/material.dart';

class DriverRequest extends StatefulWidget {
  const DriverRequest({super.key});

  @override
  State<DriverRequest> createState() => _DriverRequestState();
}

class _DriverRequestState extends State<DriverRequest> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}