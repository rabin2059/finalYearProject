// import 'package:merobus/Services/auth_service.dart';
// import 'package:merobus/States/auth_notifier.dart';
// import 'package:http/http.dart' as http;

// class UserService {
//   final String baseUrl;

//   UserService({required this.baseUrl});

//   Future<Map<String, dynamic>> getUser(int userId) async {
//     try {
//       final url = Uri.parse('${baseUrl}getUser?id=$userId');
//     } catch (e) {
      
//     }
//   }
// }